#include <stdio.h>
#include <string.h>
#include<stdlib.h>
int main()
{
char*p="test";
 char*q="TEST";
 strcpy(p,q);
 return 0;
}