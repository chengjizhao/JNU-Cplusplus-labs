#include <stdio.h>

int main()
{
    int*p=0;
    *p=1;
    return 0;
}